'use strict';
const unavailable=/weatherSheet|internetSearch|mapSheet|navigateItem|speakItem|stopSpeech|calendarItem|cityInstall/;
function cleanBasic(){document.querySelectorAll('[onclick]').forEach(b=>{if(unavailable.test(b.getAttribute('onclick')))b.remove()});document.querySelectorAll('#weatherHome,.installStrip').forEach(b=>b.remove());document.querySelectorAll('.menurow').forEach(b=>{if(b.textContent.includes('服务端城市内容'))b.remove()})}
for(const k of Object.keys(featureGroups))featureGroups[k]=featureGroups[k].map(([title,items])=>[title,items.filter(x=>!unavailable.test(x[2]))]).filter(x=>x[1].length);
featureGroups.tools.push(['整理与保存',[['出行清单','整理证件、行李与预约事项','checklist()','☑'],['备份与恢复','导出记录或导入已有备份','backupSheet()','▤']]]);
const basicRender=render;render=function(){basicRender();cleanBasic()};
const basicDetail=openItem;openItem=function(k){basicDetail(k);cleanBasic()};
const basicSheet=sheet;sheet=function(html){basicSheet(html);cleanBasic()};
const basicMine=minePage;minePage=function(){basicMine();$('#app').insertAdjacentHTML('afterbegin','<div class="panel"><h2>本浏览器的旅行记录</h2><p>无需登录。收藏、笔记、行程和消费只保存在当前浏览器，清除浏览器数据或更换设备后不会自动恢复。建议定期导出备份。</p><p class="note">原在线版记录不会自动迁移，可导入之前导出的备份。</p></div>')};
restoreBackup=function(){try{const b=window.pendingBackup;if(!b)return;validateBackup(b);localStorage.setItem('chengji-basic-state',JSON.stringify(b.data));location.reload()}catch(e){toast(e.message||'恢复失败')}};
about=function(){sheet('<h1>城迹 · 基础网页版</h1><p>保留10座城市、151个地点、120种美食及资料照片，支持搜索、故事、主题路线、行程整理、预算、收藏笔记和文件导出。</p><p>天气、在线地图、系统日历和云同步暂不提供。内容是整理的参考资料，不代表实时营业、价格或预约信息。</p><p>记录仅保存在当前浏览器，请及时导出备份。</p>')};
offlineSheet=about;
render();
const basicIncoming=new URL(location.href).searchParams.get('item');if(basicIncoming&&validSharedItem(basicIncoming))openItem(basicIncoming);
