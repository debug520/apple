'use strict';
function cityShareUrl(key){const u=new URL('travel.html',location.href);if(key)u.searchParams.set('item',key);return u.href}
function validSharedItem(key){if(typeof key!=='string'||!/^([a-z]+):(places|foods):(0|[1-9][0-9]{0,5})$/.test(key))return false;return !!resolve(key).p}
function shareFallback(text,url){sheet('<h1>分享城迹</h1><p>复制下方链接发给朋友，无需登录即可打开。对方仍需能够访问此网站。</p><textarea id="shareText" class="wide" readonly aria-label="分享内容"></textarea><button class="primary wide" id="copyShare">复制分享内容</button><p id="shareStatus" role="status"></p>');const input=document.getElementById('shareText');input.value=text+(url?'\n'+url:'');input.select();document.getElementById('copyShare').onclick=async()=>{try{if(!navigator.clipboard)throw Error();await navigator.clipboard.writeText(input.value);document.getElementById('shareStatus').textContent='已复制，可以发给朋友。'}catch{input.focus();input.select();document.getElementById('shareStatus').textContent='浏览器不允许自动复制，请长按或手动复制已选中的文字。'}}}
function sendCityShare(text,url){if(location.protocol==='file:'&&url){sheet('<h1>分享基础网页版</h1><p>本地文件地址不能发给别人访问。请发送完整网页压缩包，对方解压后打开 index.html。</p>');return}if(window.Android?.shareText){Android.shareText(text+(url?'\n'+url:''));return}if(navigator.share){navigator.share({title:'城迹 · 城市旅行助手',text,...(url?{url}:{})}).catch(e=>{if(e.name!=='AbortError')shareFallback(text,url)});return}shareFallback(text,url)}
share=function(text){sendCityShare(text,'')};
shareItem=function(key){if(!validSharedItem(key))return toast('该条目已不可用');const {c,p}=resolve(key);sendCityShare(c.name+' · '+p.name+'｜在城迹查看城市故事与旅行资料',cityShareUrl(key))};
window.shareApp=function(){sendCityShare('城迹：城市故事、美食与旅行助手，无需账号即可浏览。',cityShareUrl())};
const sharingMine=minePage;minePage=function(){sharingMine();document.getElementById('app').insertAdjacentHTML('afterbegin','<div class="panel"><button class="menurow" onclick="shareApp()"><span>↗ 把城迹分享给朋友</span><span>分享链接 ›</span></button></div>')};
render();
const sharedItem=new URL(location.href).searchParams.get('item');if(sharedItem){if(validSharedItem(sharedItem)){cid=sharedItem.split(':')[0];render();openItem(sharedItem)}else toast('分享条目不存在或链接已失效，请重新选择地点')}
