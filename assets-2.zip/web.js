'use strict';
// Browser presentation layer. All existing business flows remain connected to /api.
const webHome=home;
home=function(){webHome();const app=$('#app'),hero=app.querySelector('.hero');app.insertAdjacentHTML('afterbegin',`<div class="introHeader"><div><div class="eyebrow">EXPLORE THE STORIES WITHIN</div><h1>读懂一座城，再出发。</h1><p>从一条街的来历，到一碗汤的滋味。</p></div><div class="edition">CITY ATLAS<br>城市文化漫游手册</div></div>`);if(hero){const group=document.createElement('div');group.className='leadGrid';hero.before(group);group.append(hero);group.insertAdjacentHTML('beforeend',`<aside class="fieldNote"><div><small>THE CITY NOTE / 城市笔记</small><h2>${esc(C().tagline)}</h2><p>${esc(C().summary)}</p></div><div><button onclick="timeline()">沿着时间，认识${esc(C().name)} ↗</button><div class="countline"><div><b>${C().places.length}</b><span>地点故事</span></div><div><b>${C().foods.length}</b><span>地方风味</span></div></div></div></aside>`)}app.insertAdjacentHTML('beforeend','<footer class="portalFooter"><span>城迹 · 城市故事地图与美食文化</span><span>资料有来源 · 记录保存在本浏览器</span></footer>')};
const webSheet=sheet;sheet=function(html){webSheet(html);const s=document.querySelector('.sheet');if(s){s.setAttribute('role','dialog');s.setAttribute('aria-modal','true');s.setAttribute('aria-label',s.querySelector('h1')?.textContent||'旅行工具');s.querySelector('button[aria-label="关闭"]')?.focus()}};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#overlay').innerHTML){e.preventDefault();closeOverlay()}});
const oldValidateBackup=validateBackup;
function convertNativeBackup(b){
 if(b?.format!=='chengji-native-1')return b;
 const s=b.state;if(!s||typeof s!=='object'||Array.isArray(s))throw Error('原生备份格式无效');
 const d={saved:s.saved||[],visited:s.visited||[],notes:s.notes||{},plans:{},expenses:[],checklist:[],city:cid};
 for(const [id,steps] of Object.entries(s.plans||{})){if(!Array.isArray(steps))throw Error('行程格式无效');d.plans[id]=steps.map(x=>({...x,time:''}))}
 d.expenses=(s.expenses||[]).map(e=>({id:e.id,city:e.city,amount:e.amount,type:'其他',note:e.title||''}));
 d.checklist=Object.entries(s.checklist||{}).map(([text,done])=>({text,done}));
 // Native budget is global; allocate only to the selected city, never multiply it across cities.
 if(s.budget!==undefined)d['budget:'+cid]=s.budget;
 return {app:'chengji',version:2,data:d,exportedAt:b.exportedAt,nativeImport:true};
}
validateBackup=function(b){return oldValidateBackup(convertNativeBackup(b))};
backupSheet=function(){sheet(`<h1>把旅行记忆留好</h1><div class="panel"><h2>导出完整备份</h2><p>收藏、足迹、笔记、行程、消费、偏好与清单，保存为 JSON 文件，不含访客凭证。</p><button class="primary wide" onclick="exportBackup()">下载备份</button></div><div class="panel"><h2>恢复网页 / 原生版备份</h2><p>支持城迹网页备份和原生 1.x 备份。确认后替换本浏览器保存的记录；请先备份。原生总预算仅转入当前城市，避免重复计入。</p><button class="secondary wide" onclick="$('#backupInput').click()">选择备份文件</button></div><p class="note">记录仅保存在本浏览器。换设备可用备份迁移，不会自动同步。</p>`)};
about=function(){sheet('<h1>城迹 · 网页版</h1><div class="panel"><h2>打开网页，开始探索</h2><p>保留城市探索、景点与美食、故事时间轴、来源、对比、地图、天气、搜索、行程、收藏、足迹、笔记、预算、清单、备份与旅行手账。</p><p>无需账号；匿名记录通过浏览器安全凭证隔离保存，凭证过期或清除浏览器数据后不能自动找回。</p><p>朗读、下载、分享与日历通过浏览器能力或文件完成，支持情况由浏览器决定。没有离线业务模式。</p><p>规则规划不是 AI；在线预订、支付、实时交通优化、菜单识图与社区投稿未接入。历史及店铺实用信息请核对资料来源。</p></div>')};
const webHead=head;head=function(){webHead();document.querySelectorAll('#nav button').forEach((b,i)=>{b.setAttribute('aria-current',['home','place','food','trip','mine'][i]===tab?'page':'false')})};
const pwaHome=home;home=function(){pwaHome();const el=document.createElement('div');el.className='installStrip';el.innerHTML='<img src="/icons/city-192.png" alt="" width="44" height="44"><div><strong>把城迹放进口袋</strong><small>添加到手机桌面，下次一触即达 · 需联网</small></div><button data-pwa-action onclick="window.cityInstall.open()">添加到桌面 ↗</button>';document.querySelector('.introHeader')?.after(el)};
const pwaMine=minePage;minePage=function(){pwaMine();document.getElementById('app').insertAdjacentHTML('afterbegin','<div class="panel"><button class="menurow" data-pwa-action onclick="window.cityInstall.open()"><span>▣ 添加城迹到手机桌面</span><span>安卓 / 苹果 ›</span></button></div>')};
render();
