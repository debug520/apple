'use strict';
function travelOverview(list,start,now=new Date()){
 const date=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);const v=t=>parts.find(p=>p.type===t).value;const today=`${v('year')}-${v('month')}-${v('day')}`;
 const offset=start?Math.floor((Date.parse(today+'T00:00:00Z')-Date.parse(start+'T00:00:00Z'))/86400000)+1:null;
 const active=Number.isFinite(offset)&&offset>=1?offset:1;
 const steps=list.map((s,i)=>({...s,index:i})).filter(s=>s.day===active);
 return {today,day:active,dated:!!start,future:offset!==null&&offset<1,steps,done:steps.filter(s=>s.done).length,next:steps.find(s=>!s.done)};
}
window.dashboardTrip=function(d){day=d;go('trip')};
function travelDashboard(){
 const c=C(),list=tripList(),o=travelOverview(list,read('date:'+cid,'')),next=o.next,point=next?resolve(next.key).p:null,budget=Number(read('budget:'+cid,0)),cost=totalCost();
 const check=read('checklist',[]),pending=check.filter(x=>!x.done),n=c.places.length,seed=Number(o.today.replaceAll('-','')),storyIndex=n?seed%n:0,story=c.places[storyIndex];
 const label=!o.dated?'第 1 天预览':o.future?'出发日预览':'今天 · 第 '+o.day+' 天';
 $('#app').innerHTML=`<div class="introHeader"><div><div class="eyebrow">YOUR DAILY CITY BRIEF</div><h1>${esc(c.name)}，今天慢慢走。</h1><p>${o.today} · 你的旅行概览</p></div><button class="secondary" onclick="shareApp()">分享城迹 ↗</button></div>
 <button id="weatherHome" class="weatherStrip wide" onclick="weatherSheet()" aria-label="查看在线天气"></button>
 <div class="dashboardGrid"><section class="journeyFocus"><span class="eyebrow">NEXT CHAPTER / 下一站</span><h2>${point?esc(point.name):o.steps.length?'这一天，已完成':'给旅程留一个开始'}</h2><p>${point?esc(point.story||point.description):'把喜欢的地点加入行程，这里会显示下一项未完成安排。'}</p><div class="row"><span>${label}${next?' · '+(next.time||'时间待定'):''}</span>${next?`<button class="primary" onclick="openItem('${esc(next.key)}')">查看这一站 ↗</button>`:`<button class="primary" onclick="planner()">开始规划 ↗</button>`}</div><p class="note">按你的行程顺序展示，不代表实时导航或营业状态。</p></section>
 <section class="panel dashboardProgress"><span class="eyebrow">TRAVEL PULSE / 旅行进度</span><h2>${o.done}<small> / ${o.steps.length} 项完成</small></h2><progress aria-label="当天行程完成进度" value="${o.done}" max="${o.steps.length||1}"></progress><p>${label} · ${o.dated?'北京时间':'设置出发日期后对应当天'}</p><button class="secondary wide" onclick="dashboardTrip(${Math.min(7,o.day)})">调整这一天</button></section></div>
 <div class="dashboardGrid"><section class="panel"><div class="row"><h2>花费有数</h2><button class="mini" onclick="expenseSheet()">记一笔 ＋</button></div><div class="moneyline">¥ ${cost.toFixed(2)} <small>本城累计消费</small></div><p>${budget>0?(cost>budget?'已超预算 ¥ '+(cost-budget).toFixed(2):'预算剩余 ¥ '+(budget-cost).toFixed(2)):'尚未设置预算，可在行程页设置。'}</p></section><section class="panel"><div class="row"><h2>出发前，再看一眼</h2><button class="mini" onclick="checklist()">管理清单 ↗</button></div>${check.length?`<p>${check.length-pending.length} / ${check.length} 项已准备</p><p>${pending.length?pending.slice(0,3).map(x=>esc(x.text)).join(' · '):'清单已全部完成，出发前再核对预约。'}</p>`:'<p>证件、充电器、预约凭证……建立自己的出行清单。</p>'}</section></div>
 ${story?`<section class="storyDaily"><div><span class="eyebrow">ONE STORY A DAY / 每日读城</span><h2>${esc(story.name)}</h2><p>${esc(story.nameOrigin||story.story)}</p><button class="secondary" onclick="openItem('${c.id}:places:${storyIndex}')">读完整故事与来源 ↗</button></div><div class="storyNumber">${String(storyIndex+1).padStart(2,'0')}<small>城市故事选读</small></div></section>`:''}
 <div class="section"><h2>换个角度认识城市</h2><p class="muted">景点和美食目录已收进底部导航，首页留给你的旅程。</p></div><div class="dashboardTools"><button onclick="timeline()"><b>城市时间轴</b><span>沿年代读懂这座城 ↗</span></button><button onclick="mapSheet()"><b>地图找点</b><span>把故事放回街巷 ↗</span></button><button onclick="routesSheet()"><b>主题漫游</b><span>串起一条文化路线 ↗</span></button></div><footer class="portalFooter">基础网页版 · 记录保存在本浏览器 · 行程时间请自行核实</footer>`;

};
