'use strict';
window.remoteState={};
try{const s=JSON.parse(localStorage.getItem('chengji-basic-state')||'{}');if(s&&typeof s==='object'&&!Array.isArray(s))window.remoteState=s}catch{}
window.cloudSave=function(k,v){window.remoteState[k]=v;try{localStorage.setItem('chengji-basic-state',JSON.stringify(window.remoteState))}catch{if(window.toast)toast('浏览器未能保存，请及时导出备份')}};
