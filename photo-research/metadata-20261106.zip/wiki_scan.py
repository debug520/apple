import json,pathlib,urllib.parse,subprocess,concurrent.futures,time
R=pathlib.Path(__file__).parent;(R/'wiki').mkdir(exist_ok=True)
rs=[r for r in json.loads((R/'records.json').read_text()) if not r['file']];titles=list(dict.fromkeys(r['name'] for r in rs));groups=[titles[i:i+15] for i in range(0,len(titles),15)]
def fetch(pair):
 i,ts=pair;p=R/'wiki'/f'{i:03}.json'
 if p.exists():return json.loads(p.read_text())
 q={'action':'query','format':'json','titles':'|'.join(ts),'redirects':1,'prop':'pageimages|extracts|pageprops','piprop':'original','exintro':1,'explaintext':1,'exchars':900,'exlimit':'max'}
 u='https://zh.wikipedia.org/w/api.php?'+urllib.parse.urlencode(q)
 r=subprocess.run(['curl','-Ls','--retry','2','--retry-delay','10','--max-time','40','-A','ChengjiPhotoResearch/1.0 (https://github.com/debug520/apple)',u],capture_output=True)
 try:d=json.loads(r.stdout)
 except Exception:d={'error':r.stdout.decode(errors='replace')[:200]}
 p.write_text(json.dumps(d,ensure_ascii=False));return d
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 for i,d in enumerate(ex.map(fetch,enumerate(groups))):
  results.append(d)
  if (i+1)%10==0:print({'done':i+1,'total':len(groups),'images':sum(sum('original' in p for p in d.get('query',{}).get('pages',{}).values()) for d in results),'errors':sum('error' in d for d in results)},flush=True)
print('WIKI_COMPLETE',flush=True)
