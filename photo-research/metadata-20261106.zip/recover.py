import pathlib,json,subprocess,urllib.parse,concurrent.futures
R=pathlib.Path(__file__).parent;rows=[x.split('\t',1) for x in (R/'reviewed.tsv').read_text().splitlines()];(R/'metadata').mkdir(exist_ok=True)
def call(group):
 idx,rs=group;dest=R/'metadata'/f'{idx:03}.json'
 if dest.exists():return
 p={'action':'query','format':'json','titles':'|'.join('File:'+r[1] for r in rs),'prop':'imageinfo','iiprop':'url|extmetadata','iiurlwidth':1000}
 url='https://commons.wikimedia.org/w/api.php?'+urllib.parse.urlencode(p)
 r=subprocess.run(['curl','-Ls','--retry','2','--retry-delay','10','--max-time','40','-A','ChengjiPhotoResearch/1.0 (https://github.com/debug520/apple)',url],capture_output=True)
 d=json.loads(r.stdout);dest.write_text(json.dumps(d,ensure_ascii=False));print(idx,len(d.get('query',{}).get('pages',{})),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(call,enumerate([rows[i:i+15] for i in range(0,len(rows),15)])))
print('METADATA_READY',flush=True)
