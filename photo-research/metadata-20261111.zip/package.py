import json,pathlib,subprocess,concurrent.futures,hashlib,io,html,re,zipfile
from PIL import Image,ImageOps
R=pathlib.Path(__file__).parent;ROOT=R.parent
rows=dict(line.split('\t',1) for line in ((R/'reviewed.tsv').read_text()+(R/'extra.tsv').read_text()).splitlines());records={r['key']:r for r in json.loads((R/'records.json').read_text())}
metadata={}
for f in list((R/'metadata').glob('*.json'))+list((R/'extra-metadata').glob('*.json')):
 d=json.loads(f.read_text())
 for p in d.get('query',{}).get('pages',{}).values():metadata[p['title'][5:]]=p
 (R/'images').mkdir(exist_ok=True)
clean=lambda s:re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>',' ',s))).strip()
captions={'dunhuang:places:24':'白马塔园内壁画细节。','dali:places:18':'鸡足山景区猕猴。','guangzhou:foods:28':'烧鹅濑粉中的烧鹅，展示一种菜品搭配。','hangzhou:foods:18':'鱼头豆腐备料展示，非烹调后的成品。','kunming:foods:20':'包浆豆腐，烹调前的食材形态。','beijing:places:39':'北京海洋馆展出的中华鲟。','guangzhou:foods:9':'叉烧酥与其他下午茶点心同盘展示。','guangzhou:foods:17':'鸡仔饼售卖展示，图片标价不是当前价格。','tianjin:foods:10':'杨村糕干包装示例。','xian:places:31':'从广运大桥眺望西安世博园。','shenzhen:places:23':'大芬油画村浮雕细节。','suzhou:places:21':'苏州上方山森林公园山顶弥勒像。','xiamen:foods:9':'画面右侧为芋包。','qingdao:places:34':'金沙滩啤酒节会场入口，非当前活动实况。'}
def get(pair):
 key,title=pair;r=records[key];p=metadata.get(title)
 if not p or 'imageinfo' not in p:return {'error':'missing metadata','key':key,'title':title}
 ii=p['imageinfo'][0];m=ii['extmetadata'];fid=hashlib.sha256(ii['url'].encode()).hexdigest()[:20];dest=R/'images'/(fid+'.jpg')
 if not dest.exists():
  q=subprocess.run(['curl','-Ls','--retry','2','--retry-delay','5','--max-time','30','--max-filesize','20000000','-A','ChengjiPhotoResearch/1.0 (https://github.com/debug520/apple)',ii.get('thumburl') or ii['url']],capture_output=True)
  try:
   im=ImageOps.exif_transpose(Image.open(io.BytesIO(q.stdout)));im.load();im.thumbnail((800,800));im.convert('RGB').save(dest,format='JPEG',quality=73,optimize=True)
  except Exception as e:return {'error':str(e),'key':key,'title':title}
 entry={'key':key,'city':key.split(':')[0],'type':r['type'],'name':r['name'],'file':'verified-photos/'+key.replace(':','-')+'.jpg','source':ii['descriptionurl'],'originalImage':ii['url'],'sourceTitle':p['title'][5:],'artist':clean(m.get('Artist',{}).get('value','')),'license':m.get('LicenseShortName',{}).get('value',''),'licenseUrl':(m.get('LicenseUrl',{}).get('value','') or (ii['descriptionurl']+'#Licensing' if m.get('LicenseShortName',{}).get('value')=='Public domain' else '')).replace('http://','https://'),'scope':'dish-reference' if r['type']=='foods' else 'place-reference','identityEvidence':'已核对来源文件、城市或菜品身份及照片内容。文件说明：'+clean(m.get('ImageDescription',{}).get('value',''))[:300]+('。菜品参考照，不代表当地指定门店出品。' if r['type']=='foods' else '。地点资料照，非当日实况。'),'checkedAt':'2026-11-11','modification':'等比缩放、JPEG压缩；未裁切主体。','sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'localFile':str(dest)}
 if key in captions:entry['photoCaption']=captions[key]
 if not all(entry[k] for k in ['artist','license','licenseUrl']):return {'error':'incomplete attribution','key':key,'title':title}
 return entry
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for i,r in enumerate(pool.map(get,rows.items())):
  results.append(r)
  if (i+1)%20==0:print({'done':i+1,'total':len(rows),'errors':sum('error' in r for r in results)},flush=True)
(R/'ready.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('READY',len(results),flush=True)
