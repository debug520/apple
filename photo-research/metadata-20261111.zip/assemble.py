import json,pathlib,zipfile,hashlib,subprocess
from PIL import Image
R=pathlib.Path(__file__).parent;root=R.parent;rows=json.loads((R/'ready.json').read_text());assert len(rows)==219
assert not [r for r in rows if 'error' in r],[r for r in rows if 'error' in r]
m=json.loads(subprocess.check_output(['git','show','HEAD:verified-photo-manifest.json']));assert len(m['items'])==121
assets={};seen={}
for r in rows:
 r=dict(r);b=pathlib.Path(r.pop('localFile')).read_bytes();sha=hashlib.sha256(b).hexdigest();assert sha==r['sha256']
 with Image.open(pathlib.Path('photo-work/images')/ (hashlib.sha256(r['originalImage'].encode()).hexdigest()[:20]+'.jpg')) as im:im.verify()
 if sha in seen:r['file']=seen[sha]
 else:seen[sha]=r['file'];assets[r['file']]=b
 if r['key']=='harbin:places:33':r['photoCaption']='群力国家城市湿地公园入口标识。'
 if r['key']=='zhuhai:places:17':r['photoCaption']='东澳岛东澳村公共建筑。'
 if r['key']=='shanghai:places:39':r['photoCaption']='广富林考古遗址资料照片，非当前园区全景。'
 if r['key']=='shanghai:places:28':r['photoCaption']='东方绿舟园区的航空母舰模型。'
 m['items'].append(r)
m['checkedAt']='2026-11-11';m['notes'].append(f'2026-11-11第三批：{len(assets)}张真实照片补齐219条内容，覆盖28城；细节及备料照片补充场景说明，保留作者、许可及来源。')
(root/'verified-photo-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
groups=[];g=[];size=0
for f,b in assets.items():
 if g and size+len(b)>340000:groups.append(g);g=[];size=0
 g.append((f,b));size+=len(b)
if g:groups.append(g)
archives=[]
for idx,g in enumerate(groups,32):
 p=root/f'assets-verified-photos-{idx:02}.zip'
 with zipfile.ZipFile(p,'w',zipfile.ZIP_STORED) as z:
  for f,b in g:z.writestr(f,b)
 archives.append(p.name)
report={'addedRecords':219,'addedImageFiles':len(assets),'addedCities':len({r['city'] for r in rows}),'totalPhotoRecords':1012,'remainingWithoutPhoto':948,'archives':archives,'bytes':sum(len(v) for v in assets.values())}
(R/'release.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
p=root/'MAP-EXPLORER.md';p.write_text(p.read_text()+'\n\n## 2026-11-11 图片补充\n\n本批新增'+str(len(assets))+'个真实照片文件，补齐219条内容，涉及28城。1960条内容中1012条有图，948条仍待确认对应的照片。保留作者、许可、来源和压缩记录；细节和备料照片补充场景说明。图片同源托管，最长边800像素。\n')
print(report)
